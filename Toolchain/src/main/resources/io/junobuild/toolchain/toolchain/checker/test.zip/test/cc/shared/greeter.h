#ifndef C_SHARED_GREETER_H_
#define C_SHARED_GREETER_H_

#ifdef _MSC_VER
#ifdef DLL_EXPORT
#define DLL_API __declspec(dllexport)
#else
#define DLL_API __declspec(dllimport)
#endif
#else
#define DLL_API
#endif

DLL_API void greet(char* message);

#endif  // C_SHARED_GREETER_H_