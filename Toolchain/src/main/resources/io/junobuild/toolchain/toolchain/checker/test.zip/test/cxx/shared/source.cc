#include <greeter.h>

int main() {
  Greeter g("Hello, World!");
  g.Greet();
  return 0;
}