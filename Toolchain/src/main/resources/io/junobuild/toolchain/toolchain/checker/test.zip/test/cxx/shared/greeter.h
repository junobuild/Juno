#ifndef CXX_SHARED_GREETER_H_
#define CXX_SHARED_GREETER_H_

#ifdef _MSC_VER
#ifdef DLL_EXPORT
#define DLL_API __declspec(dllexport)
#else
#define DLL_API __declspec(dllimport)
#endif
#else
#define DLL_API
#endif

#include <string>

class DLL_API Greeter {
 public:
  Greeter(const std::string& msg);

  void Greet() const;

 private:
  std::string Message_;
};

#endif  // CXX_SHARED_GREETER_H_