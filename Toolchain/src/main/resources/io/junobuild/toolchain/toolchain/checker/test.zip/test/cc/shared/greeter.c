#define DLL_EXPORT
#include "greeter.h"

#include <stdio.h>

void greet(char* message) { printf("%s\n", message); }