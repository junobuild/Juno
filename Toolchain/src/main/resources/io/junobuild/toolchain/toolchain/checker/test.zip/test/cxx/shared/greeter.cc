#include "greeter.h"

#include <iostream>

Greeter::Greeter(const std::string& msg) : Message_(msg) {}

void Greeter::Greet() const { std::cout << Message_ << "\n"; }