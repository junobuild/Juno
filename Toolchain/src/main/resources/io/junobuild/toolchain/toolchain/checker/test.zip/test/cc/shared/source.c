#include <greeter.h>

#include <stdio.h>

int main(int argc, char* argv[]) {
  greet("Hello, World!");
  return 0;
}