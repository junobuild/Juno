#include <stdio.h>

int main(int argc, char* argv[]) {
  printf("Program %s prints: Hello, World!\n", argv[0]);
  return 0;
}