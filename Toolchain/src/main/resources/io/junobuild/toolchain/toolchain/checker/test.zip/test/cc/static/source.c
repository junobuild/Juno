#include <greeter.h>

int main() {
  greet("Hello, World!");
  return 0;
}