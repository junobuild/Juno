#ifndef C_STATIC_GREETER_H_
#define C_STATIC_GREETER_H_

void greet(char* message);

#endif  // C_STATIC_GREETER_H_