#include <iostream>

int main(int argc, char** argv) {
  std::cout << "Program " << argv[0] << " printed: Hello, World!\n";
  return 0;
}