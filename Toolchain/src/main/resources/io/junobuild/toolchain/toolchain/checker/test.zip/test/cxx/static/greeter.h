#ifndef CXX_SHARED_GREETER_H_
#define CXX_SHARED_GREETER_H_

#include <string>

class Greeter {
 public:
  Greeter(const std::string& msg);

  void Greet() const;

 private:
  std::string Message_;
};

#endif  // CXX_SHARED_GREETER_H_